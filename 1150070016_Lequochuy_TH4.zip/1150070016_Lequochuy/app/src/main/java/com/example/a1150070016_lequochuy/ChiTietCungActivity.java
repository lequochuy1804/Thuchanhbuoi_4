package com.example.a1150070016_lequochuy;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;

public class ChiTietCungActivity extends AppCompatActivity {

    private ImageView imgCung;
    private TextView tvTitle;
    private TextView tvContent;

    private String[] cungNames = {
            "Bạch Dương - Aries (21/3 - 19/4)",
            "Kim Ngưu - Taurus (20/4 - 20/5)",
            "Song Tử - Gemini (21/5 - 21/6)",
            "Cự Giải - Cancer (22/6 - 22/7)",
            "Sư Tử - Leo (23/7 - 22/8)",
            "Xử Nữ - Virgo (23/8 - 22/9)",
            "Thiên Bình - Libra (23/9 - 23/10)",
            "Bọ Cạp - Scorpio (24/10 - 21/11)",
            "Nhân Mã - Sagittarius (22/11 - 21/12)",
            "Ma Kết - Capricorn (22/12 - 19/1)",
            "Bảo Bình - Aquarius (20/1 - 18/2)",
            "Song Ngư - Pisces (19/2 - 20/3)"
    };

    private String[] cungDescriptions = {
            "Bạch Dương là cung đầu tiên, đại diện cho lửa. Người Bạch Dương thường mạnh mẽ, quyết đoán và năng động. Họ tự tin, có khả năng lãnh đạo và không ngại thử thách. Điểm yếu là đôi khi nóng tính, thiếu kiên nhẫn.",
            "Kim Ngưu thuộc nguyên tố đất, tính cách ổn định và kiên định. Họ rất kiên nhẫn, chăm chỉ, giỏi quản lý tiền bạc. Yêu thích sự an toàn, ổn định. Nhược điểm là có thể cứng nhắc, khó thay đổi.",
            "Song Tử là cung không khí, linh hoạt và thông minh. Họ tò mò, học hỏi nhanh, giao tiếp tốt và có nhiều bạn bè. Đôi khi thiếu tập trung, dễ thay đổi ý định.",
            "Cự Giải thuộc nước, nhạy cảm và ấm áp. Họ quan tâm gia đình, bạn bè, có trực giác tốt. Yêu thích sự an toàn trong mối quan hệ. Có thể quá nhạy cảm, dễ tổn thương.",
            "Sư Tử đại diện cho lửa, tự tin và hào phóng. Họ tự hào, sáng tạo, thích được công nhận. Có khả năng truyền cảm hứng. Đôi khi quá tự cao, cần được chú ý.",
            "Xử Nữ là cung đất, cẩn thận và tỉ mỉ. Họ thực tế, chăm chỉ, phân tích tốt, chú ý chi tiết. Nhược điểm là quá cầu toàn, hay chỉ trích.",
            "Thiên Bình thuộc không khí, hài hòa và công bằng. Họ lịch sự, có gu thẩm mỹ, giỏi giải quyết xung đột. Đôi khi do dự, khó quyết định.",
            "Bọ Cạp đại diện cho nước, mạnh mẽ và bí ẩn. Họ quyết đoán, trực giác tốt, khả năng phục hồi cao. Có thể quá ghen tuông, khó tin tưởng.",
            "Nhân Mã là cung lửa, lạc quan và phiêu lưu. Họ nhiệt tình, thích khám phá, có tầm nhìn xa, yêu tự do. Đôi khi bốc đồng, thiếu cam kết.",
            "Ma Kết thuộc đất, tham vọng và kiên định. Họ thực tế, chăm chỉ, lãnh đạo tốt, đặt mục tiêu cao. Có thể quá nghiêm túc, thiếu linh hoạt.",
            "Bảo Bình là cung không khí, độc lập và sáng tạo. Họ thông minh, tư duy tiến bộ, thích giúp đỡ người khác. Đôi khi quá lý tưởng, xa cách cảm xúc.",
            "Song Ngư đại diện cho nước, nhạy cảm và sáng tạo. Họ đồng cảm, trực giác tốt, có khả năng nghệ thuật. Yêu thích hòa hợp. Có thể quá mơ mộng, thiếu thực tế."
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chi_tiet_cung);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        imgCung = findViewById(R.id.imgCung);
        tvTitle = findViewById(R.id.tvTitle);
        tvContent = findViewById(R.id.tvContent);
        TextView tvBack = findViewById(R.id.tvBack);

        tvBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        int position = getIntent().getIntExtra("position", 0);

        tvTitle.setText(cungNames[position]);
        tvContent.setText(cungDescriptions[position]);
        loadCungImage(position);
    }

    private void loadCungImage(int position) {
        try {
            String fileName = "photo/cung" + (position + 1) + ".jpg";
            InputStream is = getAssets().open(fileName);
            Bitmap bmp = BitmapFactory.decodeStream(is);
            imgCung.setImageBitmap(bmp);
            is.close();
        } catch (IOException e) {
            try {
                String fileName = "photo/cung" + (position + 1) + ".webp";
                InputStream is = getAssets().open(fileName);
                Bitmap bmp = BitmapFactory.decodeStream(is);
                imgCung.setImageBitmap(bmp);
                is.close();
            } catch (IOException ex) {
                ex.printStackTrace();
                imgCung.setImageResource(android.R.drawable.ic_menu_gallery);
            }
        }
    }
}

