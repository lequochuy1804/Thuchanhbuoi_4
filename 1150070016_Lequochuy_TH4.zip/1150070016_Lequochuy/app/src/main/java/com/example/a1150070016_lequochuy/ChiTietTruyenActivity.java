package com.example.a1150070016_lequochuy;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class ChiTietTruyenActivity extends AppCompatActivity {

    private TextView tvTitle;
    private TextView tvStoryTitle;
    private TextView tvContent;
    private ImageView imgStory;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chi_tiet_truyen);

        tvTitle = findViewById(R.id.tvTitle);
        tvStoryTitle = findViewById(R.id.tvStoryTitle);
        tvContent = findViewById(R.id.tvContent);
        imgStory = findViewById(R.id.imgStory);

        int position = getIntent().getIntExtra("position", 0);
        String title = getIntent().getStringExtra("title");
        String imageFile = getIntent().getStringExtra("imageFile");

        tvTitle.setText(title);
        tvStoryTitle.setText(title);
        loadStoryImage(imageFile);
        loadStoryContent(position);
    }

    private void loadStoryImage(String imageFile) {
        if (imageFile != null && !imageFile.isEmpty()) {
            try {
                InputStream is = getAssets().open("photo/" + imageFile);
                Bitmap bmp = BitmapFactory.decodeStream(is);
                imgStory.setImageBitmap(bmp);
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
                imgStory.setImageResource(android.R.drawable.ic_menu_gallery);
            }
        }
    }

    private void loadStoryContent(int position) {
        try {
            String fileName = "story/truyen" + (position + 1) + ".txt";
            InputStream is = getAssets().open(fileName);
            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));
            
            StringBuilder content = new StringBuilder();
            String line;
            boolean firstLine = true;
            while ((line = reader.readLine()) != null) {
                if (firstLine && line.trim().isEmpty()) {
                    firstLine = false;
                    continue;
                }
                if (firstLine) {
                    firstLine = false;
                    continue;
                }
                content.append(line).append("\n");
            }
            
            reader.close();
            is.close();
            
            tvContent.setText(content.toString().trim());
        } catch (IOException e) {
            e.printStackTrace();
            tvContent.setText("Không thể đọc nội dung truyện.");
        }
    }
}

