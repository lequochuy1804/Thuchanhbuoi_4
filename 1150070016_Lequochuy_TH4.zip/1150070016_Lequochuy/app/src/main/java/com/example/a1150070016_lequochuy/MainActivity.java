package com.example.a1150070016_lequochuy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.google.android.material.button.MaterialButton;

import java.io.IOException;
import java.io.InputStream;

public class MainActivity extends AppCompatActivity {

    private ImageView imgLogo;
    private MaterialButton btnStart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imgLogo = findViewById(R.id.imgLogo);
        btnStart = findViewById(R.id.btnStart);

        loadLogo();

        btnStart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, danhsachtruyen.class);
                startActivity(intent);
            }
        });
    }

    private void loadLogo() {
        try {
            InputStream is = getAssets().open("photo/Truyencuoithieunhi.jpg");
            Bitmap bmp = BitmapFactory.decodeStream(is);
            imgLogo.setImageBitmap(bmp);
            is.close();
        } catch (IOException e) {
            e.printStackTrace();
            imgLogo.setImageResource(android.R.drawable.ic_menu_gallery);
        }
    }
}
