package com.example.a1150070016_lequochuy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;

import java.io.IOException;
import java.io.InputStream;

public class cunghoangdaoact extends AppCompatActivity {

    private ImageView[] imgCungs = new ImageView[12];
    private String[] cungNames = {
            "Bạch Dương", "Kim Ngưu", "Song Tử", "Cự Giải",
            "Sư Tử", "Xử Nữ", "Thiên Bình", "Bọ Cạp",
            "Nhân Mã", "Ma Kết", "Bảo Bình", "Song Ngư"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cung_hoang_dao);

        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }

        initViews();
        loadImages();
        setupClickListeners();
    }

    private void initViews() {
        imgCungs[0] = findViewById(R.id.imgCung1);
        imgCungs[1] = findViewById(R.id.imgCung2);
        imgCungs[2] = findViewById(R.id.imgCung3);
        imgCungs[3] = findViewById(R.id.imgCung4);
        imgCungs[4] = findViewById(R.id.imgCung5);
        imgCungs[5] = findViewById(R.id.imgCung6);
        imgCungs[6] = findViewById(R.id.imgCung7);
        imgCungs[7] = findViewById(R.id.imgCung8);
        imgCungs[8] = findViewById(R.id.imgCung9);
        imgCungs[9] = findViewById(R.id.imgCung10);
        imgCungs[10] = findViewById(R.id.imgCung11);
        imgCungs[11] = findViewById(R.id.imgCung12);
    }

    private void loadImages() {
        for (int i = 0; i < 12; i++) {
            try {
                String fileName = "photo/cung" + (i + 1) + ".jpg";
                InputStream is = getAssets().open(fileName);
                Bitmap bmp = BitmapFactory.decodeStream(is);
                imgCungs[i].setImageBitmap(bmp);
                is.close();
            } catch (IOException e) {
                try {
                    String fileName = "photo/cung" + (i + 1) + ".webp";
                    InputStream is = getAssets().open(fileName);
                    Bitmap bmp = BitmapFactory.decodeStream(is);
                    imgCungs[i].setImageBitmap(bmp);
                    is.close();
                } catch (IOException ex) {
                    ex.printStackTrace();
                    imgCungs[i].setImageResource(android.R.drawable.ic_menu_gallery);
                }
            }
        }
    }

    private void setupClickListeners() {
        for (int i = 0; i < 12; i++) {
            final int position = i;
            imgCungs[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ScaleAnimation scaleAnimation = new ScaleAnimation(
                            1.0f, 0.9f, 1.0f, 0.9f,
                            Animation.RELATIVE_TO_SELF, 0.5f,
                            Animation.RELATIVE_TO_SELF, 0.5f
                    );
                    scaleAnimation.setDuration(100);
                    scaleAnimation.setAnimationListener(new Animation.AnimationListener() {
                        @Override
                        public void onAnimationStart(Animation animation) {}

                        @Override
                        public void onAnimationEnd(Animation animation) {
                            ScaleAnimation scaleBack = new ScaleAnimation(
                                    0.9f, 1.0f, 0.9f, 1.0f,
                                    Animation.RELATIVE_TO_SELF, 0.5f,
                                    Animation.RELATIVE_TO_SELF, 0.5f
                            );
                            scaleBack.setDuration(100);
                            v.startAnimation(scaleBack);
                            
                            Intent intent = new Intent(cunghoangdaoact.this, ChiTietCungActivity.class);
                            intent.putExtra("position", position);
                            intent.putExtra("cungName", cungNames[position]);
                            startActivity(intent);
                        }

                        @Override
                        public void onAnimationRepeat(Animation animation) {}
                    });
                    v.startAnimation(scaleAnimation);
                }
            });
        }
    }
}

