package com.example.a1150070016_lequochuy;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import com.google.android.material.button.MaterialButton;

import java.io.IOException;
import java.io.InputStream;

public class danhsachtruyen extends AppCompatActivity {

    private ListView lvStories;
    private MaterialButton btnCungHoangDao;

    private String[] titles = {
            "Cậu Bé Lười Đánh Răng",
            "Bạn Nhỏ Nói Dối Gặp Rắc Rối",
            "Cô Bé Hay Quên Cái Cặp",
            "Cậu Bé Thích Khoe Điểm 10",
            "Bạn Nhỏ Sợ Xin Lỗi",
            "Cậu Bé Lịch Sự Trên Xe Buýt",
            "Cô Bé Chia Sẻ Bánh Với Bạn",
            "Bạn Nhỏ Hay Giận Dỗi",
            "Cậu Bé Dũng Cảm Giúp Cụ Già",
            "Bạn Nhỏ Biết Nói Cảm Ơn"
    };


    private String[] imageFiles = {
            "truyen1.webp",
            "truyen2.jpg",
            "truyen3.jpg",
            "truyen4.jpg",
            "truyen5.jpg",
            "truyen6.jpg",
            "truyen7.jpg",
            "truyen8.jpg",
            "truyen9.jpg",
            "truyen10.jpg"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.danhsachtruyen);

        lvStories = findViewById(R.id.lvStories);
        btnCungHoangDao = findViewById(R.id.btnCungHoangDao);

        StoryAdapter adapter = new StoryAdapter(this, titles, imageFiles);
        lvStories.setAdapter(adapter);
        
        lvStories.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(danhsachtruyen.this, ChiTietTruyenActivity.class);
                intent.putExtra("position", position);
                intent.putExtra("title", titles[position]);
                intent.putExtra("imageFile", imageFiles[position]);
                startActivity(intent);
            }
        });

        btnCungHoangDao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(danhsachtruyen.this, cunghoangdaoact.class);
                startActivity(intent);
            }
        });
        
        if (getSupportActionBar() != null) {
            getSupportActionBar().hide();
        }
    }


    private static class StoryAdapter extends ArrayAdapter<String> {

        private final Context context;
        private final String[] titles;
        private final String[] imageFiles;

        public StoryAdapter(Context context, String[] titles, String[] imageFiles) {
            super(context, 0, titles);
            this.context = context;
            this.titles = titles;
            this.imageFiles = imageFiles;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            View row = convertView;
            if (row == null) {
                LayoutInflater inflater = LayoutInflater.from(context);
                row = inflater.inflate(R.layout.item_truyen, parent, false);
            }

            ImageView imgStory = row.findViewById(R.id.imgStory);
            TextView tvTitle = row.findViewById(R.id.tvStoryTitle);

            tvTitle.setText(titles[position]);


            try {
                InputStream is = context.getAssets().open("photo/" + imageFiles[position]);
                Bitmap bmp = BitmapFactory.decodeStream(is);
                imgStory.setImageBitmap(bmp);
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
                imgStory.setImageResource(android.R.drawable.ic_menu_gallery);
            }

            return row;
        }
    }
}
